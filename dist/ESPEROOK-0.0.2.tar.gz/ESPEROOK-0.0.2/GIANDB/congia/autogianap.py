def sumSimple(nun1, num2):
    return nun1 + num2

def restSimple(nun1, num2):
    return nun1 - num2